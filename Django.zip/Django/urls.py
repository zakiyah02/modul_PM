from django.conf.urls import url,include
from django.contrib import admin

from . import views

urlpatterns = [
    url(r'^jet/', include('jet.urls', 'jet')),  # Django JET URLS
    url(r'^jet/dashboard/', include('jet.dashboard.urls', 'jet-dashboard')),  # Django JET dashboard URLS
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.index),
    url(r'^tampildiary/', views.tampil),
]
