from django.shortcuts import render

from diary.forms import TulisDiary
from diary.models import Diary

def index(request):
    obj_diary = TulisDiary()

    context = {
        'OD':obj_diary,
    }

    if request.method == "POST":
        Diary.objects.create(
            judul = request.POST.get('judul'),
            mood = request.POST.get('pilih_mood'),
            tulisan = request.POST.get('tulisan'),
        )

    return render(request, 'index.html', context)

def tampil(request):
    tampungDiary = Diary.objects.all()

    context = {
        'TD':tampungDiary,
    }

    return render(request, 'tampil.html', context)